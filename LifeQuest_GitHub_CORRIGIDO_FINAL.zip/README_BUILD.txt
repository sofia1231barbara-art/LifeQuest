LifeQuest — projeto Android corrigido

CORREÇÃO PRINCIPAL:
- Removida a dependência AndroidX AppCompat que estava a introduzir bibliotecas Kotlin incompatíveis.
- O LifeQuest usa agora apenas Android nativo + WebView.
- Não há dependências Kotlin no módulo da aplicação.

Objetivo: gerar o Android App Bundle (AAB) para publicação na Google Play.

Configuração:
- compileSdk 35
- targetSdk 35
- minSdk 23
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Java 17 no GitHub Actions
