LIFEQUEST — PROJETO ANDROID

Este ZIP contém o projeto Android da app LifeQuest, preparado para abrir no Android Studio.

COMO GERAR O AAB
1. Instala o Android Studio no Windows ou Mac: https://developer.android.com/studio
2. Extrai este ZIP para uma pasta.
3. No Android Studio: File > Open e escolhe a pasta que contém settings.gradle.
4. Espera o Gradle Sync terminar e aceita a instalação de SDKs se o Android Studio pedir.
5. Vai a Build > Generate Signed Bundle / APK.
6. Escolhe Android App Bundle e Next.
7. Cria/seleciona uma keystore de assinatura e termina o assistente.
8. O ficheiro .aab será criado na pasta indicada pelo Android Studio.

PUBLICAÇÃO
O AAB é depois enviado na Google Play Console. A conta de programador, verificação, ficha da loja, política de privacidade e publicação têm de ser feitas na conta Google do proprietário.

NOTA
O ambiente onde este projeto foi preparado não tinha Android SDK/Gradle, por isso o AAB não foi falsamente incluído neste ZIP. O projeto é a base para a compilação no Android Studio.
