LIFEQUEST - GITHUB BUILD

1. Upload LifeQuest_FINAL_ANDROID.zip to the repository root.
2. Upload .github/workflows/build-aab.yml to the repository at:
   .github/workflows/build-aab.yml
3. Open the Actions tab and run "Build LifeQuest AAB" with "Run workflow".
4. When finished, open the workflow run and download the "LifeQuest-AAB" artifact.

NOTE: The first build uses the existing debug/release configuration. Google Play publishing will require a proper signed release configuration / Play App Signing setup.
